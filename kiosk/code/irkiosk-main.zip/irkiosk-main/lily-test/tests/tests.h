#ifndef LILY_META_TESTS_H
#define LILY_META_TESTS_H

#define run_test(test) _run_test(#test, test)
void _run_test(const char *name, const char* (*test)());
int validate_message(const char* received, const char* expected,
		     const char* FILE, unsigned int LINE);

// test cases
#define TESTS \
	X(test_LILY_LOCATION) \
	X(test_LILY_COUNTER) \
	X(test_LILY_COUNTER_DECREMENT) \
	X(test_auto_registration) \
	X(test_INFO) \
	X(test_CHECK) \
	X(test_CHECK_EQ) \
	X(test_CHECK_EQF) \
	X(test_CHECK_EQS) \
	X(test_CHECK_EQS_NULL) \
	X(test_REQUIRE) \
	X(test_REQUIRE_EQ) \
	X(test_REQUIRE_EQF) \
	X(test_REQUIRE_EQS) \
	X(test_REQUIRE_EQS_NULL) \

#define X(test) const char * test();
TESTS
#undef X

#endif
