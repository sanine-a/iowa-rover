#include "lily-test.h"
#include "tests.h"


const char * test_INFO()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;

	INFO("the number is %d", 10);
	INFO("the string is '%s'", "hello world");

	if (lily_g.failed)
		return "INFO caused failure!";
	
	if (lily_g.HEAD.next == NULL)
		return "INFO did not append any messages!";
	
	lily_test_msg_t *m = lily_g.HEAD.next;
	if (strcmp(m->msg, "the number is 10") != 0)
		return "the first message is incorrect";
	
	m = m->next;
	if (m == NULL)
		return "there is not a second message!";
	
	if (strcmp(m->msg, "the string is 'hello world'") != 0)
		return "the second message is incorrect";
	
	if (m->next != NULL)
		return "too many messages";
	
	lily_msg_destroy(lily_g.HEAD.next);
	return 0;
}


const char * test_CHECK()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;
	CHECK(1 == 0);
	CHECK(0 == 0);
	CHECK(4 == 3);
	
	if (lily_g.HEAD.next == NULL)
		return "CHECK did not append any failure messages";
	lily_test_msg_t *m = lily_g.HEAD.next;

	if (strcmp(m->msg, "CHECK failed: 1 == 0") != 0)
		return "first assert has wrong message";

	if (m->next == NULL)
		return "only one message appended";
	m = m->next;
	
	if (strcmp(m->msg, "CHECK failed: 4 == 3") != 0)
		return "second message is incorrect";
	
	if (m->next != NULL)
		return "more than two messages appended!";

	if (!lily_g.failed)
		return "test did not fail!";

	lily_msg_destroy(lily_g.HEAD.next);
	
	return 0;
}


const char * test_CHECK_EQ()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;

	int k = 5;
	CHECK_EQ(k, 5, "%d");
	CHECK_EQ(4, k, "%02d");

	if (lily_g.HEAD.next == NULL)
		return "CHECK_EQ did not append any failure message";
	
	if (lily_g.HEAD.next->next != NULL)
		return "CHECK_EQ appended more than one message";
	
	if (strcmp(lily_g.HEAD.next->msg, "CHECK failed: 4 == k\n    4 = 04\n    k = 05") != 0)
		return "incorrect message";
	
	lily_msg_destroy(lily_g.HEAD.next);
	return 0;
}


const char * test_CHECK_EQF()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;

	lily_set_epsilon(0.2);
	CHECK_EQF(0.5, 0.4, "%0.1f");
	CHECK_EQF(0.5, 0.0, "%0.1f");

	if (lily_g.HEAD.next == NULL)
		return "CHECK_EQF did not append any failure message";

	if (lily_g.HEAD.next->next != NULL)
		return "CHECK_EQF appended more than one message";
	
	if (strcmp(
		lily_g.HEAD.next->msg, 
		"CHECK failed: 0.5 == 0.0\n    0.5 = 0.5\n    0.0 = 0.0\n    epsilon: 0.200000"
	) != 0)
		return "incorrect message";
	
	lily_msg_destroy(lily_g.HEAD.next);
	return 0;
}


const char * test_CHECK_EQS()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;

	const char *a = "hi";
	const char *b = "bye";
	CHECK_EQS(a, b);
	CHECK_EQS("hi hi"+3, a);

	if (lily_g.HEAD.next == NULL)
		return "CHECK_EQS did not append any failure message";

	if (lily_g.HEAD.next->next != NULL)
		return "CHECK_EQS appended more than one message";
	
	if (strcmp(
		lily_g.HEAD.next->msg, 
		"CHECK failed: a == b\n    a = \"hi\"\n    b = \"bye\""
	) != 0)
		return "incorrect message";
	
	lily_msg_destroy(lily_g.HEAD.next);
	return 0;
}

const char * test_CHECK_EQS_NULL()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;

	const char *a = "hi";
	const char *b = "bye";
	CHECK_EQS(a, NULL);
	CHECK_EQS(a, "hi");

	if (lily_g.HEAD.next == NULL)
		return "CHECK_EQS did not append any failure message";

	if (lily_g.HEAD.next->next != NULL)
		return "CHECK_EQS appended more than one message";
	
	if (strcmp(
		lily_g.HEAD.next->msg, 
		"CHECK failed: a == NULL\n    a = \"hi\"\n    NULL = \"(null)\""
	) != 0)
		return "incorrect message";
	
	lily_msg_destroy(lily_g.HEAD.next);
	return 0;
}




int aR, bR;
static void f_test_REQUIRE()
{
	aR = 5;
	REQUIRE(2+2 == 5);
	bR = 5;
}

const char * test_REQUIRE()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;
	aR = 0; bR = 0;
	int test_failed = setjmp(lily_g.env);

	if (test_failed) {
		if (!lily_g.failed)
			return "test did not fail!";

		if (lily_g.HEAD.next == NULL)
			return "test did not generate any messages";

		if (strcmp(lily_g.HEAD.next->msg, "REQUIRE failed: 2+2 == 5") != 0)
			return "test generated incorrect message";

		if (lily_g.HEAD.next->next != NULL)
			return "test generated too many messages";

		if (bR == 5)
			return "test kept executing after failed REQUIRE";

		lily_msg_destroy(lily_g.HEAD.next);
		return 0;
	}
	else {
		f_test_REQUIRE();
		return "test function did not longjump!";
	}
}


void f_test_REQUIRE_EQ()
{
	REQUIRE_EQ(2, 2, "%d");
	REQUIRE_EQ(2, 4, "%d");
	REQUIRE_EQ(2, 1, "%d");
}

const char * test_REQUIRE_EQ()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;
	int test_failed = setjmp(lily_g.env);

	if (test_failed) {
		if (!lily_g.failed)
			return "test did not mark itself as failed";

		if (lily_g.HEAD.next == NULL)
			return "test did not generate any messages";

		if (strcmp(lily_g.HEAD.next->msg, "REQUIRE failed: 2 == 4\n    2 = 2\n    4 = 4") != 0)
			return "test generated incorrect message";

		if (lily_g.HEAD.next->next != NULL)
			return "test generated too many messages";

		lily_msg_destroy(lily_g.HEAD.next);
		return 0;
	}
	else {
		f_test_REQUIRE_EQ();
		return "test function did not longjump!";
	}
}


void f_test_REQUIRE_EQF()
{
	lily_set_epsilon(0.2);
	REQUIRE_EQF(0.5, 0.0, "%0.1f");
	REQUIRE_EQF(0.5, 0.4, "%0.1f");
}

const char * test_REQUIRE_EQF()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;
	int test_failed = setjmp(lily_g.env);

	if (test_failed) {
		if (lily_g.HEAD.next == NULL)
			return "REQUIRE_EQF did not append any failure message";
	
		if (lily_g.HEAD.next->next != NULL)
			return "REQUIRE_EQF appended more than one message";
		
		if (strcmp(
			lily_g.HEAD.next->msg, 
			"REQUIRE failed: 0.5 == 0.0\n    0.5 = 0.5\n    0.0 = 0.0\n    epsilon: 0.200000"
		) != 0)
			return "incorrect message";
		
		lily_msg_destroy(lily_g.HEAD.next);
		return 0;
	}
	else {
		f_test_REQUIRE_EQF();
		return "test continued to run!";
	}
}


void f_test_REQUIRE_EQS()
{
	const char *a = "hi";
	const char *b = "bye";
	REQUIRE_EQS(a, b);
	REQUIRE_EQS("hi hi"+3, a);
}
const char * test_REQUIRE_EQS()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;
	int test_failed = setjmp(lily_g.env);

	if (test_failed) {
		if (lily_g.HEAD.next == NULL)
			return "REQUIRE_EQS did not append any failure message";
	
		if (lily_g.HEAD.next->next != NULL)
			return "REQUIRE_EQS appended more than one message";
		
		if (strcmp(
			lily_g.HEAD.next->msg, 
			"REQUIRE failed: a == b\n    a = \"hi\"\n    b = \"bye\""
		) != 0)
			return "incorrect message";
		
		lily_msg_destroy(lily_g.HEAD.next);
		return 0;
	}
	else {
		f_test_REQUIRE_EQS();
		return "test continued to run!";
	}
}

void f_test_REQUIRE_EQS_NULL()
{
	const char *a = "hi";
	const char *b = "bye";
	REQUIRE_EQS(a, NULL); 
	REQUIRE_EQS("hi hi"+3, a);
}
const char * test_REQUIRE_EQS_NULL()
{
	lily_g.HEAD.next = NULL;
	lily_g.TAIL = &(lily_g.HEAD);
	lily_g.failed = 0;
	int test_failed = setjmp(lily_g.env);

	if (test_failed) {
		if (lily_g.HEAD.next == NULL)
			return "REQUIRE_EQS did not append any failure message";
	
		if (lily_g.HEAD.next->next != NULL)
			return "REQUIRE_EQS appended more than one message";
		
		if (strcmp(
			lily_g.HEAD.next->msg, 
			"REQUIRE failed: a == NULL\n    a = \"hi\"\n    NULL = \"(null)\""
		) != 0)
			return "incorrect message";
		
		lily_msg_destroy(lily_g.HEAD.next);
		return 0;
	}
	else {
		f_test_REQUIRE_EQS_NULL();
		return "test continued to run!";
	}

}
