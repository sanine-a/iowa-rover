#include <string.h>
#include "lily-test.h"
#include "tests.h"


const char * test_LILY_LOCATION()
{
	/* do NOT move the following line, or this test will break! */
	if (strcmp(LILY_LOCATION, "tests/macro-tests.c:9") != 0 && strcmp(LILY_LOCATION, "tests\\macro-tests.c:9") != 0) {
		return "LILY_LOCATION refers to the wrong location!";
	}
	return 0;
}


const char * test_LILY_COUNTER()
{
	if (LILY_COUNTER != 0) {
		return "LILY_COUNTER is not 0!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 1) {
		return "LILY_COUNTER is not 1!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 2) {
		return "LILY_COUNTER is not 2!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 3) {
		return "LILY_COUNTER is not 3!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 4) {
		return "LILY_COUNTER is not 4!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 5) {
		return "LILY_COUNTER is not 5!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 6) {
		return "LILY_COUNTER is not 6!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 7) {
		return "LILY_COUNTER is not 7!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 8) {
		return "LILY_COUNTER is not 8!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 9) {
		return "LILY_COUNTER is not 9!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 10) {
		return "LILY_COUNTER is not 10!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 11) {
		return "LILY_COUNTER is not 11!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 12) {
		return "LILY_COUNTER is not 12!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 13) {
		return "LILY_COUNTER is not 13!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 14) {
		return "LILY_COUNTER is not 14!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 15) {
		return "LILY_COUNTER is not 15!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 16) {
		return "LILY_COUNTER is not 16!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 17) {
		return "LILY_COUNTER is not 17!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 18) {
		return "LILY_COUNTER is not 18!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 19) {
		return "LILY_COUNTER is not 19!";
	}

	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 20) {
		return "LILY_COUNTER is not 20!";
	}

	return 0;
}


const char * test_LILY_COUNTER_DECREMENT()
{
	if (LILY_COUNTER != 20) 
		return "LILY_COUNTER is not 20!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 19) 
		return "LILY_COUNTER is not 19!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 18) 
		return "LILY_COUNTER is not 18!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 17) 
		return "LILY_COUNTER is not 17!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 16) 
		return "LILY_COUNTER is not 16!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 15) 
		return "LILY_COUNTER is not 15!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 14) 
		return "LILY_COUNTER is not 14!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 13) 
		return "LILY_COUNTER is not 13!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 12) 
		return "LILY_COUNTER is not 12!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 11) 
		return "LILY_COUNTER is not 11!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 10) 
		return "LILY_COUNTER is not 10!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 9) 
		return "LILY_COUNTER is not 9!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 8) 
		return "LILY_COUNTER is not 8!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 7) 
		return "LILY_COUNTER is not 7!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 6) 
		return "LILY_COUNTER is not 6!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 5) 
		return "LILY_COUNTER is not 5!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 4) 
		return "LILY_COUNTER is not 4!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 3) 
		return "LILY_COUNTER is not 3!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 2) 
		return "LILY_COUNTER is not 2!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 1) 
		return "LILY_COUNTER is not 1!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 0) 
		return "LILY_COUNTER is not 0!";
	
	#define LILY_COUNTER_DECREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 0xfff) 
		return "LILY_COUNTER is not 0xfff!";
	
	#define LILY_COUNTER_INCREMENT
	#include "lily-test.h"

	if (LILY_COUNTER != 0)
		return "LILY_COUNTER is not 0 again!";
	
	return 0;
}


LILY_FILE_BEGIN(unique_identifier)


int array[3] = { 0, 0, 0 };

LILY_TEST("set array[0] to 1")
{
	array[0] = 1;
}
#include LILY_PUSH_TEST()


LILY_TEST("set array[1] to 2")
{
	array[1] = 2;
}
#include LILY_PUSH_TEST()


LILY_TEST("set array[2] to 3")
{
	array[2] = 3;
}
#include LILY_PUSH_TEST()


#define LILY_FILE_END
#include LILY_REGISTER_TESTS()

const char * test_auto_registration()
{
	lily_ll_node_t *n = &LILY_LIST_HEAD;
	if (n->next == NULL) {
		return "No functions were registered!";
	}
	if (n->next == n) {
		return "List loops!";
	}

	while (n->next != NULL) {
		n->f();
		n = n->next;
	}

	if (array[0] != 1)
		return "Function 0 didn't run!";
	if (array[1] != 2)
		return "Function 1 didn't run!";
	if (array[2] != 3)
		return "Function 2 didn't run!";

	return 0;
}
