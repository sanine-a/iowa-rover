#include <stdio.h>

#include "tests.h"

void _run_test(const char *name, const char* (*test)())
{
   printf("%s... ", name);
   const char *result = test();
   if (result != 0) {
      printf("FAILED: %s\n", result);
   }
   else
      printf("OK\n");
}
