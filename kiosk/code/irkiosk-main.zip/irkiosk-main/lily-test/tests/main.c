#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#define LILY_IMPLEMENTATION
#include "lily-test.h"
#include "tests.h"

int main()
{
	#define X(test) run_test(test);
	TESTS
	#undef X
	return 0;
}
