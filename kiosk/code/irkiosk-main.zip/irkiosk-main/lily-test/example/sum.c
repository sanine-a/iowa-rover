#define LILY_IMPLEMENTATION
#include "lily-test.h"

int sum(int a, int b)
{
	return 0;
}


LILY_FILE_BEGIN(sum_suite)

LILY_TEST("sums are correct")
{
	CHECK_EQ(sum(0, 0), 0, "%d");
	CHECK_EQ(sum(1, 0), 1, "%d");
	INFO("this is some info");
	CHECK_EQ(sum(2, 2), 4, "%d");
}
#include LILY_PUSH_TEST()

#define LILY_FILE_END
#include LILY_REGISTER_TESTS()


int main()
{
	lily_begin();
	sum_suite();
	lily_finish();
	return 0;
}
