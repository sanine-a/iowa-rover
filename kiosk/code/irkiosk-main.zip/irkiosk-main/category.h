#pragma once

// included so that we also get CATEGORY_UNKNOWN
#include "Rfid/HashTable.h"

#define CATEGORY_FORWARD  0
#define CATEGORY_BACKWARD 1
#define CATEGORY_LEFT     2
#define CATEGORY_RIGHT    3
